package com.example.firstsubmission.ui.home

import androidx.lifecycle.ViewModel
import com.example.firstsubmission.data.MovieCatalogue
import com.example.firstsubmission.utils.DataDummy

class HomeViewModel: ViewModel() {

    private lateinit var dummyCatalogue: List<MovieCatalogue>

    fun setType(type: Int){
        if (type == 2){
            dummyCatalogue = DataDummy.generateDataTvShowDummy()
        }else{
            dummyCatalogue = DataDummy.generateDataMovieDummy()
        }
    }
    fun getCatalogue(): List<MovieCatalogue> = dummyCatalogue
}