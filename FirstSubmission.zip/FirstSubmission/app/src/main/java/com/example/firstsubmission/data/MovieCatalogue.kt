package com.example.firstsubmission.data

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class MovieCatalogue(
    var id: String,
    var title: String,
    var desc: String,
    var poster: String,
    var img_preview: String
) : Parcelable
