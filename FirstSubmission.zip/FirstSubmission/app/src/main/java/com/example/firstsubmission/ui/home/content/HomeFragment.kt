package com.example.firstsubmission.ui.home.content

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.firstsubmission.data.MovieCatalogue
import com.example.firstsubmission.databinding.FragmentHomeBinding
import com.example.firstsubmission.ui.home.HomeViewModel

class HomeFragment : Fragment() {
    private lateinit var fragmentHomeBinding: FragmentHomeBinding
    companion object{
       private const val ARG_SECTION_NUMBER = "section_number"
       @JvmStatic
        fun newInstance(index: Int) =
           HomeFragment().apply {
               arguments = Bundle().apply {
                   putInt(ARG_SECTION_NUMBER, index)
               }
           }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        fragmentHomeBinding = FragmentHomeBinding.inflate(layoutInflater, container, false)
        return fragmentHomeBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())[HomeViewModel::class.java]
        val index = arguments?.getInt(ARG_SECTION_NUMBER, 0)

        index?.let { viewModel.setType(it) }
        var catalogue: List<MovieCatalogue> = viewModel.getCatalogue()

        val catalogueAdapter = index?.let { CatalogueAdapter(it) }
        catalogueAdapter?.setCatalogue(catalogue)
        with(fragmentHomeBinding.rvCalaogue){
            layoutManager = LinearLayoutManager(context)
            setHasFixedSize(true)
            adapter = catalogueAdapter
        }
    }
}