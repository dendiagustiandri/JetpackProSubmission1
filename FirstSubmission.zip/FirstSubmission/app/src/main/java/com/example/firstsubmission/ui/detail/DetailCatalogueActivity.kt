package com.example.firstsubmission.ui.detail

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import com.example.firstsubmission.R
import com.example.firstsubmission.data.MovieCatalogue
import com.example.firstsubmission.databinding.ActivityDetailCatalogueBinding
import com.example.firstsubmission.databinding.ContentDetailBinding
import com.example.firstsubmission.utils.Helper

class DetailCatalogueActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_CATALOGUE = "extra_catalogue"
        const val EXTRA_TYPE = "extra_type"
    }

    private lateinit var detailCatalogueBinding: ActivityDetailCatalogueBinding
    private lateinit var contentDetailBinding: ContentDetailBinding
    private lateinit var result: MovieCatalogue

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        detailCatalogueBinding = ActivityDetailCatalogueBinding.inflate(layoutInflater)
        contentDetailBinding = detailCatalogueBinding.detailContent
        setContentView(detailCatalogueBinding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        detailCatalogueBinding.collapsingToolbar.setExpandedTitleColor(Color.TRANSPARENT)

        val extras = intent.extras
        val catalogueId = extras?.getString(EXTRA_CATALOGUE)
        val catalogueType = extras?.getInt(EXTRA_TYPE)

        val viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())[DetailCatalogueViewModel::class.java]
        catalogueType?.let { viewModel.setType(it) }
        catalogueId?.let { viewModel.selectedCatalogue(it) }
        result = viewModel.getCatalogue()

        if (catalogueType == 1) {
            setupToolbarTitle(resources.getString(R.string.tab_text_1))
        }else{
            setupToolbarTitle(resources.getString(R.string.tab_text_2))
        }

        contentDetailBinding.tvDetailName.text = result.title
        contentDetailBinding.tvDetailDesc.text = result.desc
        Helper.setImageWithGlide(this, result.poster, contentDetailBinding.imgDetailPoster)
        Helper.setImageWithGlide(this, result.img_preview, detailCatalogueBinding.imgDetailHightlight)

    }

    private fun setupToolbarTitle(title: String) {
        supportActionBar?.title = title
    }
    override fun onSupportNavigateUp(): Boolean {
        finish()
        return super.onSupportNavigateUp()
    }
}