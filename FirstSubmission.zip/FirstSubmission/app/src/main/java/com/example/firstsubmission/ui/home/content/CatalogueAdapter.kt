package com.example.firstsubmission.ui.home.content



import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.firstsubmission.R
import com.example.firstsubmission.databinding.ItemCatalogueBinding
import com.example.firstsubmission.data.MovieCatalogue
import com.example.firstsubmission.ui.detail.DetailCatalogueActivity

class CatalogueAdapter(private val index: Int) : RecyclerView.Adapter<CatalogueAdapter.CatalogueViewHolder>(){

    private var listCatalogue = ArrayList<MovieCatalogue>()
    inner class CatalogueViewHolder(private val binding: ItemCatalogueBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(catalogue: MovieCatalogue){
            with(binding){
                tvItemTitle.text = catalogue.title
                tvItemDesc.text = catalogue.desc
                Glide.with(itemView.context)
                    .load(catalogue.poster)
                    .apply {
                        RequestOptions.placeholderOf(R.drawable.ic_baseline_refresh_24)
                            .error(R.drawable.ic_baseline_broken_image_24)
                    }
                    .into(imgItemPoster)
                imgItemPoster.setOnClickListener {
                    val intent = Intent(itemView.context, DetailCatalogueActivity::class.java)
                    intent.putExtra(DetailCatalogueActivity.EXTRA_CATALOGUE, catalogue.id)
                    intent.putExtra(DetailCatalogueActivity.EXTRA_TYPE, index)
                    itemView.context.startActivity(intent)
                }
            }
        }
    }

    fun setCatalogue(catalogue: List<MovieCatalogue>){
        if (catalogue == null) return
        this.listCatalogue.clear()
        this.listCatalogue.addAll(catalogue)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CatalogueViewHolder {
        val itemCatalogueBinding = ItemCatalogueBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CatalogueViewHolder(itemCatalogueBinding)
    }

    override fun onBindViewHolder(holder: CatalogueViewHolder, position: Int) {
        holder.bind(listCatalogue[position])
    }

    override fun getItemCount(): Int = listCatalogue.size

}