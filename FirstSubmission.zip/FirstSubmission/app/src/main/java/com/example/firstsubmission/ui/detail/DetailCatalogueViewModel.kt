package com.example.firstsubmission.ui.detail

import androidx.lifecycle.ViewModel
import com.example.firstsubmission.data.MovieCatalogue
import com.example.firstsubmission.utils.DataDummy

class DetailCatalogueViewModel: ViewModel() {

    private lateinit var catalogueId: String
    private lateinit var dummyCatalogue: List<MovieCatalogue>

    fun selectedCatalogue(catalogueId: String){
        this.catalogueId = catalogueId
    }

    fun setType(type: Int){
        if (type == 2){
            dummyCatalogue = DataDummy.generateDataTvShowDummy()
        }else{
            dummyCatalogue = DataDummy.generateDataMovieDummy()
        }
    }

    fun getCatalogue() : MovieCatalogue{
        lateinit var catalogue: MovieCatalogue
        val list = dummyCatalogue
        for (data in list){
            if (data.id == catalogueId){
                catalogue = data
                break
            }
        }
        return catalogue
    }

}