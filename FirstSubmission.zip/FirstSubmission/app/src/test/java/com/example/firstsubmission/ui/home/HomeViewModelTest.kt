package com.example.firstsubmission.ui.home

import org.junit.Test

import org.junit.Assert.*
import org.junit.Before

class HomeViewModelTest {

    private lateinit var viewModel: HomeViewModel

    @Before
    fun setup(){
        viewModel = HomeViewModel()
    }

    @Test
    fun getCatalogueMovie() {
        viewModel.setType(1)
        val catalogue = viewModel.getCatalogue()
        assertNotNull(catalogue)
        assertEquals(10, catalogue.size)
    }

    @Test
    fun getCatalogueTvShows() {
        viewModel.setType(2)
        val catalogue = viewModel.getCatalogue()
        assertNotNull(catalogue)
        assertEquals(10, catalogue.size)
    }

}