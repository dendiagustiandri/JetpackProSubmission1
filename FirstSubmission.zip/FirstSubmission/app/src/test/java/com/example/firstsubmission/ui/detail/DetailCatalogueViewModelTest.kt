package com.example.firstsubmission.ui.detail

import com.example.firstsubmission.utils.DataDummy
import org.junit.Before
import org.junit.Assert.*
import org.junit.Test

class DetailCatalogueViewModelTest {

    private lateinit var viewModel: DetailCatalogueViewModel
    private val dummyMovie = DataDummy.generateDataMovieDummy()[0]
    private val dummyTvShow = DataDummy.generateDataTvShowDummy()[0]

    @Before
    fun setup(){
        viewModel = DetailCatalogueViewModel()
    }

    @Test
    fun getCatalogueMoive() {
        viewModel.setType(1)
        viewModel.selectedCatalogue(dummyMovie.id)
        val movie = viewModel.getCatalogue()
        assertNotNull(movie)
        assertEquals(dummyMovie.id, movie.id)
        assertEquals(dummyMovie.title, movie.title)
        assertEquals(dummyMovie.desc, movie.desc)
        assertEquals(dummyMovie.img_preview, movie.img_preview)
        assertEquals(dummyMovie.poster, movie.poster)
    }

    @Test
    fun getCatalogueTvShow(){
        viewModel.setType(2)
        viewModel.selectedCatalogue(dummyTvShow.id)
        val tvshow = viewModel.getCatalogue()
        assertNotNull(tvshow)
        assertEquals(dummyTvShow.id, tvshow.id)
        assertEquals(dummyTvShow.title, tvshow.title)
        assertEquals(dummyTvShow.desc, tvshow.desc)
        assertEquals(dummyTvShow.img_preview, tvshow.img_preview)
        assertEquals(dummyTvShow.poster, tvshow.poster)
    }
}