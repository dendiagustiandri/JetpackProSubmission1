package com.example.firstsubmission.ui.home

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.UiController
import androidx.test.espresso.ViewAction
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.rules.ActivityScenarioRule
import com.example.firstsubmission.R
import com.example.firstsubmission.utils.DataDummy
import org.junit.Rule
import org.junit.Test

class HomeActivityTest{

    private val dummyMoview = DataDummy.generateDataMovieDummy()
    private val dummyTvShow = DataDummy.generateDataTvShowDummy()

    @get:Rule
    var activityRule = ActivityScenarioRule(HomeActivity::class.java)

    @Test
    fun loadCatalogueMovie(){
        onView(withId(R.id.rv_calaogue)).check(matches(isDisplayed()))
        onView(withId(R.id.rv_calaogue)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(dummyMoview.size))
    }

    @Test
    fun loadDetailCatalogue(){
        onView(withId(R.id.rv_calaogue)).perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, clickOnViewChild(R.id.img_item_poster)))
        onView(withId(R.id.tv_detail_name)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_detail_name)).check(matches(withText(dummyMoview[0].title)))
        onView(withId(R.id.tv_label_desc)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_label_desc)).check(matches(withText(R.string.description)))
        onView(withId(R.id.tv_detail_desc)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_detail_desc)).check(matches(withText(dummyMoview[0].desc)))
        onView(withId(R.id.img_detail_poster)).check(matches(isDisplayed()))
        onView(withId(R.id.img_detail_hightlight)).check(matches(isDisplayed()))
    }

    @Test
    fun loadCatalogueTvShow(){
        onView(withText(R.string.tab_text_2)).perform(click())
        onView(withId(R.id.rv_calaogue)).check(matches(isDisplayed()))
        onView(withId(R.id.rv_calaogue)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(dummyTvShow.size))
    }

    fun clickOnViewChild(viewId: Int) = object : ViewAction {
        override fun getConstraints() = null

        override fun getDescription() = "Click on a child view with specified id."

        override fun perform(uiController: UiController, view: View) = click().perform(uiController, view.findViewById<View>(viewId))
    }
}